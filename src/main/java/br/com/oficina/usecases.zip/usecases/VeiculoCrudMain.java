package br.com.oficina;

import br.com.oficina.domain.Veiculo;

public class VeiculoCrudMain {
    public static void main(String[] args) {
        Veiculo v = new Veiculo(
                null,              // id
                "ABC1D23",         // placa
                "Fiat",            // marca
                "Argo",            // modelo
                2020,              // ano
                "Prata",           // cor
                "Exemplo local",   // observações
                1L,                // clienteId
                true               // ativo
        );

        System.out.println("Veículo OK: " + v.getPlaca());
    }
}
