package br.com.oficina.usecases;

import br.com.oficina.domain.Cliente;
import br.com.oficina.ports.ClienteRepository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * Caso de uso "CRUD" de Cliente.
 * Mantém o domínio e o repositório puros (sem anotações de framework).
 * Regras de negócio simples e coordenação de persistência via porta (ClienteRepository).
 */
public class ClienteCrudUseCases {

    private final ClienteRepository repository;

    public ClienteCrudUseCases(ClienteRepository repository) {
        this.repository = repository;
    }

    public Cliente criar(Cliente cliente) {
        // aqui poderiam entrar validações de negócio (email único, CPF/CNPJ válidos etc.)
        return repository.save(cliente);
    }

    public Cliente atualizar(Long id, Cliente clienteNovo) {
        // garante que existe antes de atualizar
        repository.findById(id).orElseThrow(
                () -> new NoSuchElementException("cliente não encontrado")
        );
        // garante o id do path
        Cliente toSave = clienteNovo;
        if (clienteNovo.getId() == null || !id.equals(clienteNovo.getId())) {
            // o domínio expõe definirId(id) (usado pelo InMemory também)
            clienteNovo.definirId(id);
            toSave = clienteNovo;
        }
        return repository.save(toSave);
    }

    /** Atualização parcial: o merge normalmente é feito no Controller/DTO. Aqui apenas persistimos. */
    public Cliente patch(Long id, Cliente clienteMesclado) {
        repository.findById(id).orElseThrow(
                () -> new NoSuchElementException("cliente não encontrado")
        );
        if (clienteMesclado.getId() == null || !id.equals(clienteMesclado.getId())) {
            clienteMesclado.definirId(id);
        }
        return repository.save(clienteMesclado);
    }

    public Optional<Cliente> obterPorId(Long id) {
        return repository.findById(id);
    }

    public List<Cliente> listar() {
        return repository.findAll();
    }

    public boolean excluir(Long id) {
        return repository.deleteById(id);
    }
}
