package br.com.oficina.usecases;

import br.com.oficina.domain.Veiculo;
import br.com.oficina.ports.VeiculoRepository;

import java.util.Optional;

/**
 * Use case simples para leitura de um veículo por ID.
  */
public class BuscarVeiculoUseCase {

    private final VeiculoRepository repository;

    public BuscarVeiculoUseCase(VeiculoRepository repository) {
        this.repository = repository;
    }

    public Optional<Veiculo> executar(Long id) {
        return repository.findById(id);
    }
}
